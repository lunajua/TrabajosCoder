from setuptools import setup

setup(
    
    name="pre_entrega_2",
    version="1.0",
    description="Realizado en POO con módulos y paquetes",
    author="Juan Pablo Luna",
    author_email="jp_luna@hotmail.com",
    
    packages=["paquete1"]
    
)
